from django.urls import path
from . import views

urlpatterns = [
    # Ruta para la página de inicio
    path("", views.index, name="index"),
    # NUEVA RUTA: Inicia el proceso de creación de video en segundo plano
    path(
        "start_video_creation/",
        views.start_video_creation_api,
        name="start_video_creation",
    ),
    # NUEVA RUTA: Consulta el estado de una tarea de creación de video
    path(
        "video_status/<str:task_id>/",
        views.get_video_status_api,
        name="get_video_status",
    ),
]
