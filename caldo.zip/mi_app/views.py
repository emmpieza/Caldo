import os
import subprocess
import time
import requests
import wave
import whisper
import math
import numpy as np
import cv2
from PIL import ImageFont, ImageDraw, Image
import textwrap
import tempfile
import threading
from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response

# --- Almacenamiento en memoria para las tareas ---
TASKS = {}


# --- Vista para la Página Web ---
def index(request):
    """Renderiza la página principal."""
    return render(request, "mi_app/index.html")


# --- FUNCIONES AUXILIARES (Lógica de IA) ---
# (Todas las funciones de IA como generar_audio, generar_imagen, etc. se mantienen igual)
def generar_audio_con_piper(texto, nombre_archivo):
    model_path = "/app/modelos_locales/es_ES_davefx_medium.onnx"
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"El modelo de voz no fue encontrado en {model_path}.")
    temp_file_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, encoding="utf-8"
        ) as temp_file:
            temp_file.write(texto)
            temp_file_path = temp_file.name
        comando = ["piper", "--model", model_path, "--output_file", nombre_archivo]
        with open(temp_file_path, "r", encoding="utf-8") as input_file:
            resultado = subprocess.run(
                comando,
                stdin=input_file,
                check=True,
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
        if not (os.path.exists(nombre_archivo) and os.path.getsize(nombre_archivo) > 0):
            raise RuntimeError(
                f"Piper no generó un archivo válido. Info: {resultado.stderr if resultado.stderr else resultado.stdout}"
            )
        return f"Audio generado en {nombre_archivo}"
    except Exception as e:
        raise RuntimeError(f"ERROR en la generación de audio: {str(e)}")
    finally:
        if temp_file_path and os.path.exists(temp_file_path):
            os.unlink(temp_file_path)


def generar_imagen_con_sdturbo(prompt, nombre_archivo):
    import torch
    from diffusers import AutoPipelineForText2Image

    pipe = AutoPipelineForText2Image.from_pretrained(
        "stabilityai/sd-turbo", torch_dtype=torch.float32, cache_dir="./modelos_cache"
    ).to("cpu")
    image = pipe(prompt=prompt, num_inference_steps=2, guidance_scale=0.0).images[0]
    image.save(nombre_archivo)


def generar_musica_con_musicgen(prompt, duracion, nombre_archivo_con_extension):
    from audiocraft.models import MusicGen
    from audiocraft.data.audio import audio_write

    model = MusicGen.get_pretrained("facebook/musicgen-small", device="cpu")
    model.set_generation_params(duration=duracion)
    audio_values = model.generate([prompt])
    nombre_base = nombre_archivo_con_extension.replace(".wav", "")
    audio_write(nombre_base, audio_values.cpu()[0], model.sample_rate)


def transcribir_audio_con_whisper(ruta_audio):
    model = whisper.load_model("base")
    result = model.transcribe(ruta_audio)
    return result["segments"]


def verificar_video(ruta_video):
    if not os.path.exists(ruta_video) or os.path.getsize(ruta_video) < 1024:
        raise RuntimeError(
            f"VERIFICACIÓN FALLIDA: El archivo '{ruta_video}' no existe o está vacío."
        )
    cap = cv2.VideoCapture(ruta_video)
    if not cap.isOpened() or int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) <= 0:
        raise RuntimeError(
            f"VERIFICACIÓN FALLIDA: El video '{ruta_video}' es inválido o no contiene fotogramas."
        )
    cap.release()


def wrap_text_by_pixel(text, font, max_width):
    lines = []
    if font.getbbox(text)[2] <= max_width:
        return [text]
    words = text.split(" ")
    current_line = ""
    for word in words:
        test_line = current_line + " " + word if current_line else word
        if font.getbbox(test_line)[2] <= max_width:
            current_line = test_line
        else:
            lines.append(current_line)
            current_line = word
    lines.append(current_line)
    return lines


def ensamblar_video_ken_burns(
    rutas_imagenes,
    duracion_total,
    nombre_archivo_salida,
    fps=24,
    width=576,
    height=1024,
):
    video_writer = cv2.VideoWriter(
        nombre_archivo_salida, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )
    if not video_writer.isOpened():
        raise RuntimeError("ERROR al inicializar cv2.VideoWriter.")
    num_imagenes = len(rutas_imagenes)
    if num_imagenes == 0:
        video_writer.release()
        return
    duracion_por_imagen = duracion_total / num_imagenes
    frames_por_imagen = int(duracion_por_imagen * fps)
    for i, ruta_img in enumerate(rutas_imagenes):
        img_original = cv2.imread(ruta_img)
        if img_original is None:
            continue
        h_orig, w_orig, _ = img_original.shape
        ratio_destino = width / height
        w_recorte = int(h_orig * ratio_destino)
        x_inicio_recorte = (w_orig - w_recorte) // 2
        img_recortada = img_original[:, x_inicio_recorte : x_inicio_recorte + w_recorte]
        img = cv2.resize(img_recortada, (width, height))
        zoom_in = i % 2 == 0
        for f in range(frames_por_imagen):
            progreso = f / frames_por_imagen
            zoom = 1.0 + 0.15 * progreso if zoom_in else 1.15 - 0.15 * progreso
            centro_x, centro_y = width // 2, height // 2
            nueva_w, nueva_h = int(width / zoom), int(height / zoom)
            x1, y1 = max(0, centro_x - nueva_w // 2), max(0, centro_y - nueva_h // 2)
            cropped_img = img[y1 : y1 + nueva_h, x1 : x1 + nueva_w]
            resized_frame = cv2.resize(
                cropped_img, (width, height), interpolation=cv2.INTER_LINEAR
            )
            video_writer.write(resized_frame)
    video_writer.release()


def agregar_subtitulos_al_video(
    ruta_video_entrada, segmentos_whisper, nombre_archivo_salida
):
    font_path = "/app/fonts/DejaVuSans-Bold.ttf"
    if not os.path.exists(font_path):
        raise FileNotFoundError(f"Fuente no encontrada: {font_path}")
    cap = cv2.VideoCapture(ruta_video_entrada)
    if not cap.isOpened():
        raise RuntimeError(
            f"No se pudo abrir el video de entrada: {ruta_video_entrada}"
        )
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if fps <= 0 or width <= 0 or height <= 0:
        raise RuntimeError("Propiedades de video inválidas.")
    video_writer = cv2.VideoWriter(
        nombre_archivo_salida, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )
    if not video_writer.isOpened():
        raise RuntimeError("No se pudo inicializar cv2.VideoWriter.")
    font_size = int(height * 0.035)
    font = ImageFont.truetype(font_path, font_size)
    segmento_actual_idx = 0
    frames_procesados = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        timestamp_actual = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
        subtitulo_a_mostrar = ""
        if segmento_actual_idx < len(segmentos_whisper):
            segmento = segmentos_whisper[segmento_actual_idx]
            if (
                timestamp_actual >= segmento["start"]
                and timestamp_actual <= segmento["end"]
            ):
                subtitulo_a_mostrar = segmento["text"].strip()
            elif timestamp_actual > segmento["end"]:
                segmento_actual_idx += 1
        if subtitulo_a_mostrar:
            frame_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            draw = ImageDraw.Draw(frame_pil)
            lines = wrap_text_by_pixel(subtitulo_a_mostrar, font, width * 0.9)
            line_height = font.getbbox("Tg")[3] - font.getbbox("Tg")[1]
            total_text_height = len(lines) * (line_height * 1.2)
            y_text = height - total_text_height - int(height * 0.1)
            for line in lines:
                bbox = draw.textbbox((0, 0), line, font=font)
                x_text = (width - (bbox[2] - bbox[0])) / 2
                draw.text((x_text - 2, y_text - 2), line, font=font, fill=(0, 0, 0))
                draw.text((x_text + 2, y_text - 2), line, font=font, fill=(0, 0, 0))
                draw.text((x_text - 2, y_text + 2), line, font=font, fill=(0, 0, 0))
                draw.text((x_text + 2, y_text + 2), line, font=font, fill=(0, 0, 0))
                draw.text((x_text, y_text), line, font=font, fill=(255, 255, 255))
                y_text += line_height * 1.2
            frame = cv2.cvtColor(np.array(frame_pil), cv2.COLOR_RGB2BGR)
        video_writer.write(frame)
        frames_procesados += 1
    if frames_procesados == 0:
        raise RuntimeError("No se procesaron fotogramas al agregar subtítulos.")
    cap.release()
    video_writer.release()


def combinar_video_con_dos_audios(
    ruta_video, ruta_audio_voz, ruta_audio_musica, nombre_archivo_salida
):
    for ruta in [ruta_video, ruta_audio_voz, ruta_audio_musica]:
        if not os.path.exists(ruta) or os.path.getsize(ruta) == 0:
            raise RuntimeError(f"Archivo de entrada no existe o está vacío: {ruta}")
    comando = [
        "ffmpeg",
        "-y",
        "-i",
        ruta_video,
        "-i",
        ruta_audio_voz,
        "-i",
        ruta_audio_musica,
        "-filter_complex",
        "[1:a]volume=1.0[voz];[2:a]volume=0.15[musica];[voz][musica]amix=inputs=2:duration=longest[aout]",
        "-map",
        "0:v:0",
        "-map",
        "[aout]",
        "-c:v",
        "copy",
        "-c:a",
        "aac",
        "-shortest",
        nombre_archivo_salida,
    ]
    resultado = subprocess.run(comando, capture_output=True, text=True)
    if resultado.returncode != 0:
        raise RuntimeError(f"FFmpeg falló al mezclar audios: {resultado.stderr}")


def send_webhook_callback(callback_url, task_data):
    """Función para enviar la notificación del webhook."""
    if not callback_url:
        return  # No hacer nada si no hay URL
    try:
        print(f"Enviando notificación de webhook a: {callback_url}")
        requests.post(
            callback_url, json=task_data, timeout=10
        )  # 10 segundos de timeout
        print("Notificación de webhook enviada con éxito.")
    except requests.exceptions.RequestException as e:
        # Si el webhook falla, solo lo registramos, no detenemos el proceso
        print(f"ADVERTENCIA: Falló el envío del webhook a {callback_url}. Error: {e}")


# --- WORKER: La función que hace el trabajo pesado en segundo plano ---
def video_creation_worker(task_id, texto_completo, music_prompt, callback_url):
    """
    Función principal que se ejecuta en un hilo, actualiza el estado y
    envía un webhook al finalizar.
    """
    rutas = {
        "audio_voz": f"audio_voz_{task_id}.wav",
        "audio_musica": f"musica_fondo_{task_id}.wav",
        "video_base": f"video_base_{task_id}.mp4",
        "video_con_subs": f"video_con_subs_{task_id}.mp4",
        "video_final": f"video_final_{task_id}.mp4",
        "imagenes": [],
    }

    try:
        # PASO 1: Generar Audio de Voz
        TASKS[task_id].update(
            {
                "status": "in_progress",
                "progress": 10,
                "message": "Paso 1/8: Generando audio de voz...",
            }
        )
        generar_audio_con_piper(texto_completo, rutas["audio_voz"])

        # PASO 2: Medir duración y Generar Música
        TASKS[task_id].update(
            {"progress": 20, "message": "Paso 2/8: Generando música de fondo..."}
        )
        with wave.open(rutas["audio_voz"], "rb") as wf:
            duracion_audio = math.ceil(wf.getnframes() / float(wf.getframerate()))
        generar_musica_con_musicgen(music_prompt, duracion_audio, rutas["audio_musica"])

        # PASO 3: Generar Imágenes
        TASKS[task_id].update(
            {"progress": 30, "message": "Paso 3/8: Generando imágenes..."}
        )
        segundos_por_imagen = 6.0
        num_imagenes = math.ceil(duracion_audio / segundos_por_imagen)
        prompts = [p.strip() for p in texto_completo.split(".") if p.strip()] or [
            texto_completo
        ]
        for i in range(num_imagenes):
            nombre_imagen = f"imagen_{task_id}_{i+1}.png"
            generar_imagen_con_sdturbo(prompts[i % len(prompts)], nombre_imagen)
            rutas["imagenes"].append(nombre_imagen)

        # PASO 4: Ensamblar Video Base
        TASKS[task_id].update(
            {"progress": 50, "message": "Paso 4/8: Ensamblando video base..."}
        )
        ensamblar_video_ken_burns(
            rutas["imagenes"],
            duracion_total=duracion_audio,
            nombre_archivo_salida=rutas["video_base"],
        )
        verificar_video(rutas["video_base"])

        # PASO 5: Transcribir Audio para Subtítulos
        TASKS[task_id].update(
            {"progress": 65, "message": "Paso 5/8: Transcribiendo audio..."}
        )
        segmentos_subs = transcribir_audio_con_whisper(rutas["audio_voz"])

        # PASO 6: Grabar Subtítulos en el Video
        TASKS[task_id].update(
            {"progress": 75, "message": "Paso 6/8: Agregando subtítulos..."}
        )
        agregar_subtitulos_al_video(
            rutas["video_base"], segmentos_subs, rutas["video_con_subs"]
        )
        verificar_video(rutas["video_con_subs"])

        # PASO 7: Combinar Video con Voz y Música
        TASKS[task_id].update(
            {"progress": 90, "message": "Paso 7/8: Combinando video y audios..."}
        )
        combinar_video_con_dos_audios(
            rutas["video_con_subs"],
            rutas["audio_voz"],
            rutas["audio_musica"],
            rutas["video_final"],
        )
        verificar_video(rutas["video_final"])

        # PASO 8: Finalización y Notificación Webhook
        final_status = {
            "status": "completed",
            "progress": 100,
            "message": "Video creado con éxito.",
            "result_path": rutas["video_final"],
        }
        TASKS[task_id].update(final_status)
        send_webhook_callback(callback_url, TASKS[task_id])

    except Exception as e:
        import traceback

        traceback.print_exc()
        # Si algo falla, se actualiza el estado y se notifica al webhook
        failure_status = {
            "status": "failed",
            "message": f"El proceso falló. Error: {str(e)}",
        }
        TASKS[task_id].update(failure_status)
        send_webhook_callback(callback_url, TASKS[task_id])
    finally:
        # Limpieza de archivos intermedios
        print(f"Limpiando archivos para la tarea {task_id}...")
        files_to_delete = [
            rutas["audio_voz"],
            rutas["audio_musica"],
            rutas["video_base"],
            rutas["video_con_subs"],
        ] + rutas["imagenes"]
        for f in files_to_delete:
            if os.path.exists(f):
                os.remove(f)


# --- VISTAS DE API ---


@api_view(["POST"])
def start_video_creation_api(request):
    """
    Inicia el proceso de creación de video. Acepta un 'callback_url' opcional.
    """
    texto_completo = request.data.get("texto")
    music_prompt = request.data.get(
        "music_prompt", "lo-fi hip hop, calm, instrumental, chill"
    )
    callback_url = request.data.get("callback_url")  # <-- NUEVO

    if not texto_completo:
        return Response({"error": 'El campo "texto" es requerido.'}, status=400)

    task_id = str(int(time.time()))

    TASKS[task_id] = {
        "status": "pending",
        "message": "La tarea ha sido aceptada y está en cola.",
        "callback_url": callback_url,
    }

    thread = threading.Thread(
        target=video_creation_worker,
        args=(task_id, texto_completo, music_prompt, callback_url),  # <-- NUEVO
    )
    thread.start()

    return Response(
        {
            "message": "Proceso de video iniciado.",
            "task_id": task_id,
            "status_url": f"/video_status/{task_id}/",
        },
        status=202,
    )


@api_view(["GET"])
def get_video_status_api(request, task_id):
    """Consulta el estado de una tarea de creación de video."""
    task = TASKS.get(task_id)
    if not task:
        return Response({"error": "Tarea no encontrada"}, status=404)

    if task.get("status") == "completed":
        task["download_url"] = f"/download/{task.get('result_path')}"

    return Response(task)
